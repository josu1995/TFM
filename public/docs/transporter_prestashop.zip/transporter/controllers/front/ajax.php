<?php

class TransporterAjaxModuleFrontController extends ModuleFrontController
{
    public function __construct()
    {
        parent::__construct();
    }

    public function initContent()
    {
        parent::initContent();
        if (!$this->isXmlHttpRequest()) {
            Tools::redirect(__PS_BASE_URI__);
        }
        if (!$this->isTokenValid()) {
            die('Bad token');
        }

//        if ((int)$this->context->cart->id_customer !== (int)$this->context->customer->id) {
//            die("Bad token");
//        }
    }

    public function displayAjaxPostStoreOrder()
    {
        TransporterFront::postStoreOrder($_POST);
        die(Tools::jsonEncode(null));
    }
}
