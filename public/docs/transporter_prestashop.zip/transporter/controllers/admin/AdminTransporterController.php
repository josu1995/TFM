<?php

class AdminTransporterController extends ModuleAdminController
{
    public function ajaxProcessPostAdminStoreOrder()
    {
        die(TransporterAdmin::postStoreOrder(Tools::getValue('idCarrier'), Tools::getValue('idOrder'), Tools::getValue('store')));
    }
}