<?php

class AdminTabTransporterController extends ModuleAdminController
{
    public function __construct()
    {
        parent::__construct();
        Tools::redirectAdmin(Context::getContext()->link->getAdminLink('AdminModules') . '&configure=' . $this->module->name . '&tab_module=shipping_logistics&module_name=' . $this->module->name);
    }
}
