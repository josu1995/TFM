let transporterMap;
let trMarkers = [];
const imagenMarker = '/modules/transporter/views/img/transporter-marker-grey.png';
const trUsuarioMarkerImagen = '/modules/transporter/views/img/transporter-user-marker.png';
const markerActivo = '/modules/transporter/views/img/transporter-marker-active.png';
const mobile = window.screen.width < 768;

if (typeof google !== 'object' || typeof google.maps !== 'object') {
  document.write(`<script type='text/javascript' src='https://maps.googleapis.com/maps/api/js?v=3.exp&key=${TransporterCfg.mapsKey}'></script>`);
}

const Transporter = {

  getStores(carrierId) {
    if(!$('div[id^="modal-stores-search-"]').length) {
      $.fancybox.open(`#modal-stores-search-${carrierId}`, {
        transitionEffect: 'fade',
        wrapCSS: 'tr-stores-fancybox',
        parentEl: "body",
        beforeShow: function () {
          $('.tr-stores-fancybox .ver-mas-link[data-toggle=popover]').each(function initPopover() {
            $(this).popover({
              trigger: 'manual',
              placement: mobile ? 'top' : 'left',
              html: true,
              content() {
                const id = $(this).attr('id');
                return $(`.horario-table-${id}`).html();
              },
              container: 'body',
            }).data('bs.popover')
              .tip()
              .addClass('tr-popover');
          });
          Transporter.initMap();
        },
        beforeClose: function() {
          Transporter.togglePaymentModules($.fancybox.current.href);
        }
      });
    } else {
      $('div[id^="modal-stores-search-"]').modal();
    }
    Transporter.initTouchHandler();
  },
  initMap() {

    $('.close-mobile-btn').click(function() {
      if($('div[id^="modal-stores-search-"]').length) {
        $(this).parents('.modal').modal('hide');
      } else {
        $.fancybox.close();
      }
    });

    let mapCenter;

    if (trDireccion) {
      mapCenter = {lat: parseFloat(trDireccion.latitud), lng: parseFloat(trDireccion.longitud)};
    } else {
      mapCenter = {lat: parseFloat(trStores[0].latitud), lng: parseFloat(trStores[0].longitud)};
    }

    const opcionesMapa = {
      center: mapCenter,
      zoom: 14,
      disableDefaultUI: true,
      zoomControl: true,
      gestureHandling: 'cooperative',
    };

    transporterMap = new google.maps.Map($('div[id^=tr-map-]')[0], opcionesMapa);

    // Crear marker location
    new google.maps.Marker({
      position: mapCenter,
      map: transporterMap,
      title: '',
      icon: trUsuarioMarkerImagen,
      animation: google.maps.Animation.DROP,
    });

    Transporter.removeMarkers();
    trMarkers = [];
    for (let i = 0; i < trStores.length; i += 1) {
      // Creamos marker
      const marker = new google.maps.Marker({
        position: {
          lat: parseFloat(trStores[i].latitud),
          lng: parseFloat(trStores[i].longitud),
        },
        map: transporterMap,
        title: trStores[i].nombre,
        icon: imagenMarker,
        animation: google.maps.Animation.DROP,
      });

      trMarkers.push(marker);

      Transporter.crearMarkerListener(marker);
    }

    if($('div[id^="modal-stores-search-"]').length) {
      $('.ver-mas-link[data-toggle=popover]').each(function initPopover() {
        $(this).popover({
          trigger: 'manual',
          placement: mobile ? 'top' : 'left',
          html: true,
          content() {
            const id = $(this).attr('id');
            return $(`.horario-table-${id}`).html();
          },
          container: '#content',
        }).data('bs.popover')
          .tip()
          .addClass('tr-popover-new');
      });
    }

    if (!mobile) {
      $('.punto-list-item').hover(function () {
        Transporter.hoverStore($(this));
      });
    } else {
      $('.punto-list-item').on('click', function () {
        Transporter.hoverStore($(this));
      });
    }

    if(trStores && trStores.length) {
      Transporter.hoverStore($('.punto-list-item').first());
    }
  },
  hoverStore(elem) {
    let index = null;
    let storesList = null;
    let puntoListItem = null;
    if(!$('div[id^="modal-stores-search-"]').length && $('.tr-stores-fancybox').length) {
      puntoListItem = $('.tr-stores-fancybox .punto-list-item');
      index = puntoListItem.index(elem);
      storesList = $('.tr-stores-fancybox #stores-list');
    } else {
      puntoListItem = $('.punto-list-item');
      index = puntoListItem.index(elem);
      storesList = $('#stores-list');
    }
    const punto = trStores[index];
    const marker = Transporter.findMarker(punto);

    if (!mobile) {
      Transporter.clearStoresSelection();
      elem.addClass('store-active');
    } else {
      if ($('.store-active') !== elem) {
        Transporter.clearStoresSelection();
        elem.addClass('store-active');
      }
      if (index !== 0 && index !== puntoListItem.length - 1) {
        storesList.animate({
          scrollLeft: elem.width() * index - ((storesList.width() - elem.width()) / 2),
        }, {duration: 400, queue: false});
      } else {
        storesList.animate({
          scrollLeft: elem.width() * index,
        }, {duration: 400, queue: false});
      }
    }

    marker.setIcon(markerActivo);
    const center = new google.maps.LatLng(parseFloat(punto.latitud), parseFloat(punto.longitud));
    transporterMap.panTo(center);
  },
  removeMarkers() {
    for (let i = 0; i < trMarkers.length; i += 1) {
      trMarkers[i].setMap(null);
    }
  },
  findMarker(store) {
    for (let i = 0; i < trMarkers.length; i += 1) {
      const marker = trMarkers[i];
      if (parseFloat(parseFloat(marker.position.lat()).toFixed(6)) == store.latitud
        && parseFloat(parseFloat(marker.position.lng()).toFixed(6)) == store.longitud) {
        return marker;
      }
    }
    return null;
  },
  clearStoresSelection() {
    $('.store-active').removeClass('store-active');
    for (let i = 0; i < trMarkers.length; i += 1) {
      const marker = trMarkers[i];
      marker.setIcon(imagenMarker);
    }
  },
  crearMarkerListener(marker) {
    google.maps.event.addListener(marker, 'click', () => {
      let elem = null;
      if(!$('div[id^="modal-stores-search-"]').length) {
        elem = $('.tr-stores-fancybox .punto-list-item').eq(trMarkers.indexOf(marker));
      } else {
        elem = $('.punto-list-item').eq(trMarkers.indexOf(marker));
      }
      Transporter.hoverStore(elem);
      if($('div[id^="modal-stores-search-"]').length) {
        $('#stores-list').animate({
          scrollTop: elem.offset().top + elem.parent().scrollTop() - 360,
        }, 1000);
      } else {
        $('.tr-stores-fancybox #stores-list').animate({
          scrollTop: elem.offset().top + elem.parent().scrollTop() - 180,
        }, 1000);
      }
    });
  },
  postNewOrder(storeIndex) {

    const sendData = {
      ajax: true,
      action: 'postAdminStoreOrder',
      idCarrier: TransporterCfg.idCarrier,
      store: trStores[storeIndex],
      idOrder: TransporterCfg.idOrder
    };

    TransporterCfg.selectedStore = trStores[storeIndex].id;

    $.ajax(
      {
        type: 'POST',
        headers: {'cache-control': 'no-cache'},
        url: TransporterCfg.ajaxUrl,
        async: true,
        cache: false,
        dataType: 'json',
        data: sendData,
        success() {
          if($('div[id^="modal-stores-search-"]').length) {
            $(`#modal-stores-search-${sendData.idCarrier}`).modal('hide');
          } else {
            $.fancybox.close();
          }
          location.reload();
        },
        error(xhr, ajaxOptions, thrownError) {
          console.log(thrownError);
        },
      });
  },
  callAlert(error_message) {
    if (typeof $.fancybox !== typeof undefined) {
      $.fancybox.open([
          {
            type: 'inline',
            autoScale: true,
            minHeight: 30,
            content: '<p class="fancybox-error">' + error_message + '</p>'
          }],
        {
          padding: 0
        });
    } else {
      alert(error_message);
    }
  },
  togglePaymentModules(elemId) {

    if(!TransporterCfg.selectedStore && $(elemId).length) {
      $('#HOOK_PAYMENT p.payment_module').hide();
      if(!$("#HOOK_PAYMENT").find("p").hasClass("transporterwarning")) {
        $("#HOOK_PAYMENT").append('<p class="warning transporterwarning">No has seleccionado ningún store.</p>');
      } else {
        $("#HOOK_PAYMENT p.transporterwarning").html('No has seleccionado ningún store.');
      }
    } else {
      $('#HOOK_PAYMENT p.payment_module').show();
      $("#HOOK_PAYMENT").find("p.transporterwarning").remove();
    }
  },
  initTouchHandler() {

    storesList = $('.stores-list');

    storesList.on('touchstart', function(e) {
      scrollStartPos = e.originalEvent.touches[0].clientX;
      scrollStartPosY = e.originalEvent.touches[0].clientY;
    });

    storesList.on('touchmove', function(e) {
      e.preventDefault();
      e.stopImmediatePropagation();
      if(e.originalEvent.touches[0].clientX < scrollStartPos) {
        $(this)[0].scrollLeft = scrollStartPos - e.originalEvent.touches[0].clientX + storesList.scrollLeft();
      } else {
        $(this)[0].scrollLeft = scrollStartPos - e.originalEvent.touches[0].clientX + storesList.scrollLeft();
      }
      if($('div[id^="modal-stores-search-"]').length) {
        $('.modal-body')[0].scrollTop = scrollStartPosY - e.originalEvent.touches[0].clientY + $('.modal-body').scrollTop();
      }
      scrollStartPos = e.originalEvent.touches[0].clientX;
      scrollStartPosY = e.originalEvent.touches[0].clientY;
    });

    storesList.on('touchend', function(e) {
      var scrolledLeft = storesList.scrollLeft();
      var viewPortWidth = storesList.width();
      var children = storesList.children(':not(.horario-punto)');
      var elemWidth = children.first().width();

      var valToChange = 0;
      var elemToChange = null;

      for(var i = 0 ; i < children.length ; i++) {

        var visiblePixels = elemWidth - (scrolledLeft - (i * elemWidth));
        var percentVisible = visiblePixels * 100 / elemWidth;

        if(percentVisible > 100) {
          var hiddenPixels = elemWidth * (i + 1) - (scrolledLeft + viewPortWidth);
          percentVisible = (elemWidth - hiddenPixels) * 100 / elemWidth;
        }

        if(percentVisible < 0) {
          percentVisible = 0;
        } else if(percentVisible > 100) {
          percentVisible = 100;
        }

        if(percentVisible > valToChange) {
          valToChange = percentVisible;
          elemToChange = children.eq(i);
        }
      }

      Transporter.hoverStore(elemToChange);
    });
  }
};

$(() => {

  Transporter.initMap();

  $('.tr-crear-envio').click(function(e) {
    if($('div[id^="modal-stores-search-"]').length) {
      e.preventDefault();
      Transporter.getStores();
    }
  });

  if (mobile) {
    $('body').off('touchstart');
    $('body').on('touchstart ', (e) => {
      if ($('.tr-popover-new').length) {
        $('.popover.fade.in').remove();
        // $('a[data-toggle="popover"]').popover('toggle');
      } else if ($(e.target).hasClass('ver-mas-link')) {
        $(e.target).popover('show');
      }
    });
  } else {
    $('body').off('mousedown');
    $('body').on('mousedown', (e) => {
      if ($('.tr-popover-new').length) {
        $('a[data-toggle="popover"]').each(function() {
          $(this).popover('hide');
        });
      } else if ($(e.target).hasClass('ver-mas-link')) {
        $(e.target).popover('show');
      }
    });
  }
});
