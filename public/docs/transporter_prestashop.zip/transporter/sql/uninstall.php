<?php

$sql = array();

$sql[] = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'transporter_carrier`;';

$sql[] = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'transporter_store_order`;';

$sql[] = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'transporter_orders`;';

$sql[] = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'transporter_states`;';
