<?php

$sql = array();

$sql[] = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'transporter_carrier`;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'transporter_carrier` (
  `id` varchar(5) NOT NULL,
  `name` varchar(80) NOT NULL,
  `delay` varchar(80) NOT NULL,
  `account_type` int(1) NOT NULL,
  `store_delivery` int(1) NOT NULL, 
  `id_reference` int(10) unsigned NOT NULL,
  `active` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

$sql[] = 'INSERT INTO `' . _DB_PREFIX_ . "transporter_carrier` (`id`, `name`, `delay`, `account_type`, `store_delivery`, `id_reference`, `active`) VALUES
('1', 'Transporter – Envío a domicilio', '24h', 2, 0, 0, 0),
('2', 'Transporter – Envío a store', '24h', 2, 1, 0, 0),
('3', 'Transporter Baleares – Envío a domicilio', '48h', 2, 0, 0, 0),
('4', 'Transporter Baleares – Envío a store', '48h', 2, 1, 0, 0),
('5', 'Transporter Europa A – Envío a domicilio', '3-5 días', 2, 0, 0, 0),
('6', 'Transporter Europa A – Envío a store', '3-5 días', 2, 1, 0, 0),
('7', 'Transporter Europa B – Envío a domicilio', '4-6 días', 2, 0, 0, 0),
('8', 'Transporter Europa B – Envío a store', '4-6 días', 2, 1, 0, 0),
('9', 'Transporter Córcega – Envío a domicilio', '4-5 días', 2, 0, 0, 0),
('10', 'Transporter Córcega – Envío a store', '4-5 días', 2, 1, 0, 0),

('11', 'Transporter – Envío a domicilio', '48/72h', 1, 0, 0, 0),
('12', 'Transporter – Envío a store', '48/72h', 1, 1, 0, 0),
('13', 'Transporter Baleares – Envío a domicilio', '48h', 1, 0, 0, 0),
('14', 'Transporter Baleares – Envío a store', '48h', 1, 1, 0, 0),
('15', 'Transporter Europa A – Envío a domicilio', '4-6 días', 1, 0, 0, 0),
('16', 'Transporter Europa A – Envío a store', '4-6 días', 1, 1, 0, 0),
('17', 'Transporter Europa B – Envío a domicilio', '4-6 días', 1, 0, 0, 0),
('18', 'Transporter Europa B – Envío a store', '4-6 días', 1, 1, 0, 0),
('19', 'Transporter Córcega – Envío a domicilio', '4-5 días', 1, 0, 0, 0),
('20', 'Transporter Córcega – Envío a store', '4-5 días', 1, 1, 0, 0);";

$sql[] = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'transporter_store_order`;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'transporter_store_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_cart` int(10) unsigned NOT NULL,
  `id_order` int(10) unsigned NOT NULL,
  `id_carrier` int(10) unsigned NOT NULL, 
  `store` longtext COLLATE utf8_spanish_ci NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

$sql[] = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'transporter_orders`;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'transporter_orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_order` int(10) unsigned NOT NULL,
  `id_shipment` int(10) unsigned NOT NULL,
  `error` longtext,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

$sql[] = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'transporter_states`;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'transporter_states` (
  `id` int(10) unsigned NOT NULL,
  `ps_state_id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

$sql[] = 'INSERT INTO `' . _DB_PREFIX_ . "transporter_states` (`id`, `ps_state_id`, `name`, `description`) VALUES
('3', 0, 'Pendiente de Pago', 'Envío pendiente de pago'),
('4', 0, 'Pendiente de expedición', 'Envío pendiente de expedición'),
('5', 0, 'Punto de origen', 'Envío en store de origen'),
('6', 0, 'En ruta', 'Envío en ruta'),
('8', 0, 'Punto de destino', 'Envío en store de destino'),
('9', 0, 'Finalizado', 'Envío finalizado'),
('11', 0, 'Envío retornado a origen', 'Envío retornado a origen'),
('12', 0, 'Envío cancelado', 'Envío cancelado'),
('13', 0, 'En reparto', 'Envío en reparto');";