<?php

abstract class ApiCaller
{
    protected $url;

    protected $apiKey;

    protected $endpoint;

    protected $method;

    protected $body;

    protected $response;

    public function __construct($url, $apiKey)
    {
        $this->url = $url;
        $this->apiKey = $apiKey;
    }

    protected function call($body = null)
    {
        $curl = curl_init();

        if ($this->method === 'GET') {
            curl_setopt_array($curl, array(
                CURLOPT_HTTPHEADER => array(
                    'Authorization: Bearer ' . $this->apiKey,
                    'Content-type: application/json',
                ),
                CURLOPT_RETURNTRANSFER => 1,
                CURLOPT_URL => $this->url . $this->endpoint,
            ));
        } elseif ($this->method === 'POST') {
            curl_setopt_array($curl, array(
                CURLOPT_HTTPHEADER => array(
                    'Authorization: Bearer ' . $this->apiKey,
                    'Content-type: application/json',
                ),
                CURLOPT_RETURNTRANSFER => 1,
                CURLOPT_URL => $this->url . $this->endpoint,
                CURLOPT_POST => 1,
                CURLOPT_POSTFIELDS => $body,
            ));
        }

        $this->response = curl_exec($curl);

        if ($this->response != false && curl_getinfo($curl, CURLINFO_HTTP_CODE) === 200) {
            $this->response = json_decode($this->response);
        } elseif ($this->method == 'POST') {
            $this->response = [
                'errors' => json_decode($this->response)
            ];
        } else {
            $this->response = null;
        }

        curl_close($curl);
    }
}
