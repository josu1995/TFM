<?php

require_once _PS_MODULE_DIR_ . 'transporter/classes/ApiCaller.php';

class TransporterApi extends ApiCaller
{
    public function __construct($url, $apiKey)
    {
        parent::__construct($url, $apiKey);
    }

    public function validate()
    {
        $this->method = 'GET';
        $this->endpoint = '/v1/configuracion/validate';
        $this->call();

        return $this->response;
    }

    public function getDireccionRecogida()
    {
        $this->method = 'GET';
        $this->endpoint = '/v1/configuracion/direccion-recogida';
        $this->call();

        return $this->response;
    }

    public function getEstados()
    {
        $this->method = 'GET';
        $this->endpoint = '/v1/configuracion/estados';
        $this->call();

        return $this->response;
    }

    public function getTransportistas()
    {
        $this->method = 'GET';
        $this->endpoint = '/v1/configuracion/transportistas';
        $this->call();

        return $this->response;
    }

    public function getStores($address, $postcode, $city, $countryIso)
    {
        $this->method = 'GET';
        $this->endpoint = '/v1/stores?address=' . urlencode(trim($address)) . '&postcode=' . urlencode(trim($postcode)) . '&city=' . urlencode(trim($city)) . '&country=' . urlencode(trim($countryIso));
        $this->call();

        return $this->response;
    }

    public function postEnvio($params)
    {
        $this->method = 'POST';
        $this->endpoint = '/v1/shipments';
        $this->call($params);

        return $this->response;
    }

    public function getEstadoEnvio($idShipment)
    {
        $this->method = 'GET';
        $this->endpoint = '/v1/shipments/' . $idShipment . '/state';
        $this->call();

        return $this->response;
    }

    public function getEstadosEnvios($envios)
    {
        $this->method = 'GET';
        $this->endpoint = '/v1/shipments/states?module=1';
        foreach ($envios as $envio) {
            $this->endpoint .= '&shipments[]=' . $envio['id_shipment'];
        }
        $this->call();

        return $this->response;
    }
}
