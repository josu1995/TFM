<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

class TransporterCommon
{
    public static function getTransportistas($instaled = true, $where = '', $order_by = '')
    {
        $sql = 'SELECT `id`, `name`, `delay`, `store_delivery`, `id_reference` FROM `' . _DB_PREFIX_ . 'transporter_carrier` tc WHERE 1 ';

        if ($instaled) {
            $sql .= ' AND `id_reference` <> 0';
        }

        if ($where != '') {
            $sql .= ' AND ' . $where . ' AND `active`=1';
        }

        if ($order_by != '') {
            $sql .= ' ORDER BY ' . $order_by;
        }

        $transportistas = Db::getInstance()->executeS($sql);
        if (count($transportistas) == 0) {
            return false;
        } elseif (count($transportistas) == 1) {
            return $transportistas[0];
        } else {
            return $transportistas;
        }
    }

    public static function getTransporterStoreOrder($where = '', $order_by = '')
    {
        $sql = 'SELECT `id`, `id_cart`, `id_order`, `id_carrier`, `store`, `date` FROM `' . _DB_PREFIX_ . 'transporter_store_order` tc WHERE 1 ';

        if ($where != '') {
            $sql .= ' AND ' . $where;
        }

        if ($order_by != '') {
            $sql .= ' ORDER BY ' . $order_by;
        }

        $orders = Db::getInstance()->executeS($sql);
        if (count($orders) == 0) {
            return false;
        } elseif (count($orders) == 1) {
            return $orders[0];
        } else {
            return $orders;
        }
    }

    public static function getTransporterOrder($where = '', $order_by = '')
    {
        $sql = 'SELECT `id`, `id_order`, `id_shipment`, `error`, `date` FROM `' . _DB_PREFIX_ . 'transporter_orders` tc WHERE 1 ';

        if ($where != '') {
            $sql .= ' AND ' . $where;
        }

        if ($order_by != '') {
            $sql .= ' ORDER BY ' . $order_by;
        }

        $orders = Db::getInstance()->executeS($sql);
        if (count($orders) == 0) {
            return false;
        } elseif (count($orders) == 1) {
            return $orders[0];
        } else {
            return $orders;
        }
    }

    public static function getTransporterState($where = '', $order_by = '')
    {
        $sql = 'SELECT `id`, `ps_state_id`, `name`, `description` FROM `' . _DB_PREFIX_ . 'transporter_states` ts WHERE 1 ';

        if ($where != '') {
            $sql .= ' AND ' . $where;
        }

        if ($order_by != '') {
            $sql .= ' ORDER BY ' . $order_by;
        }

        $sql .= ' LIMIT 1';

        $state = Db::getInstance()->executeS($sql);
        if (count($state) == 0) {
            return false;
        } elseif (count($state) == 1) {
            return $state[0];
        } else {
            return $state;
        }
    }

    public static function getEnvioJsonFromOrder($order)
    {

        $referenciaPedido = $order->reference;

        // Productos y paquete
        $productosOrder = $order->getProducts();
        $productos = [];
        $package = [
            'width' => 0,
            'height' => 0,
            'depth' => 0,
        ];
        foreach ($productosOrder as $producto) {
            array_push($productos, [
                'name' => $producto['product_name'],
                'quantity' => $producto['product_quantity'],
                'weight' => $producto['weight']
            ]);
            if($package['width'] < $producto['width']) {
                $package['width'] = $producto['width'];
            }
            if($package['height'] < $producto['height']) {
                $package['height'] = $producto['height'];
            }
            if($package['depth'] < $producto['depth']) {
                $package['depth'] = $producto['depth'];
            }
        }

        // Destinatario
        $customerOrder = $order->getCustomer();
        $deliveryAddress = new Address($order->id_address_delivery);
        $country = new Country($deliveryAddress->id_country);
        $transporterStoreOrder = TransporterCommon::getTransporterStoreOrder('id_order = ' . $order->id);

        $store = Tools::jsonDecode($transporterStoreOrder['store']);

        return Tools::jsonEncode([
            'orderReference' => $referenciaPedido,
            'products' => $productos,
            'package' => $package,
            'customer' => [
                'firstName' => $customerOrder->firstname,
                'lastName' => $customerOrder->lastname,
                'email' => $customerOrder->email,
                'phone' => $deliveryAddress->phone_mobile ? $deliveryAddress->phone_mobile : $deliveryAddress->phone,
            ],
            'destination' => [
                'country' => $country->iso_code,
                'postcode' => $deliveryAddress->postcode,
                'address1' => $deliveryAddress->address1,
                'address2' => $deliveryAddress->address2,
                'storeId' => $store ? $store->id : null
            ]
        ]);

    }

    public static function getEnviosNoFinalizados()
    {
        if(Configuration::get('TR_ESTADOS_9')) {
            $estadoFin = Configuration::get('TR_ESTADOS_9');
        } else {
            $estadoFin = 5;
        }
        if(Configuration::get('TR_ESTADOS_11')) {
            $estadoDevuelto = Configuration::get('TR_ESTADOS_11');
        } else {
            $estadoDevuelto = 7;
        }
        if(Configuration::get('TR_ESTADOS_12')) {
            $estadoCancelado = Configuration::get('TR_ESTADOS_12');
        } else {
            $estadoCancelado = 6;
        }
        $sql = 'SELECT pto.id_shipment FROM ps_transporter_orders pto 
                WHERE (
                  select po.current_state from ps_orders po 
                  where po.id_order = pto.id_order) not in 
                      (' . $estadoFin . ',' . $estadoDevuelto . ',' . $estadoCancelado .
            ')';
        $envios = Db::getInstance()->executeS($sql);
        if (count($envios) == 0) {
            return false;
        } else {
            return $envios;
        }
    }

    public static function deleteTransporterOrder($idShipment)
    {
        Db::getInstance()->delete('transporter_orders', 'id_shipment = ' . $idShipment);
    }
}
