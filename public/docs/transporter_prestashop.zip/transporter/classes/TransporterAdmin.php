<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

class TransporterAdmin
{
    public static function addTransportista($data)
    {
        $transporter = new Transporter();
        $carrier = new Carrier();
        $carrier->name = $data->nombre;
//        $carrier->id_tax = 1;
//        $carrier->id_zone = 1;
        $carrier->active = 0;
        $carrier->deleted = 0;
        $carrier->delay = [];
        $carrier->shipping_handling = false;
        $carrier->range_behavior = 1;
        $carrier->is_module = 0;
        $carrier->shipping_external = 1;
        $carrier->external_module_name = $transporter->name;
        $carrier->need_range = true;
        $carrier->max_weight = 20;
        $carrier->url = 'https://www.transporter.es/tracking/@';
        if (version_compare(_PS_VERSION_, '1.7', '>')) {
            $carrier->is_module = 1;
        }

        $languages = Language::getLanguages(true);
        foreach ($languages as $language) {
            $carrier->delay[(int) $language['id_lang']] = $data->tiempo;
        }

        if ($carrier->add()) {
            $groups = Group::getGroups(true);
            foreach ($groups as $group) {
                Db::getInstance()->Execute(
                    'INSERT INTO `' . _DB_PREFIX_ . 'carrier_group` 
                    VALUES (\'' . (int) $carrier->id . '\',\'' . (int) $group['id_group'] . '\')'
                );
            }

            $source = _PS_MODULE_DIR_ . 'transporter/views/img/tr-square-logo.jpg';
//            if (version_compare(_PS_VERSION_, '1.7', '>')) {
//                $source = _PS_MODULE_DIR_.'correos/views/img/logo_ps17_generic.jpg';
//            }
            $destination = _PS_SHIP_IMG_DIR_ . '/' . (int) $carrier->id . '.jpg';
            copy($source, $destination);

            Db::getInstance()->update(
                'transporter_carrier',
                array('id_reference' => (int) $carrier->id),
                'id = ' . pSQL($data->id)
            );

            return $carrier;
        } else {
            return false;
        }
    }

    public static function getTransportistasCreados()
    {
        $sql = 'SELECT pc.`id_carrier`, tc.`id`, pc.`active`  
         FROM `' . _DB_PREFIX_ . 'carrier` pc 
         INNER JOIN `' . _DB_PREFIX_ . 'transporter_carrier` tc ON pc.`id_reference` = tc.`id_reference`
         WHERE pc.`deleted` = 0 AND pc.`id_reference` != 0';

        $carriers = Db::getInstance()->executeS($sql);

        if (count($carriers) == 0) {
            return false;
        }

        return $carriers;
    }

    public static function  updateOrder($order, $response)
    {
        if(array_key_exists('errors', $response)) {
            Db::getInstance()->update(
                'transporter_orders',
                array('error' => pSQL(Tools::jsonEncode($response['errors']))),
                '`id_order` = ' . (int) $order->id
            );
        } else {
            $sql = 'UPDATE `' . _DB_PREFIX_ . 'transporter_orders`
                SET `id_shipment` = ' . (int) $response . ', `error` = NULL WHERE `id_order` = ' . (int) $order->id;
            Db::getInstance()->execute($sql);
        }
    }

    public static function postStoreOrder($idCarrier, $idOrder, $store)
    {
        $order = new Order($idOrder);

        Db::getInstance()->delete(
            'transporter_store_order',
            'id_cart = ' . $order->id_cart
        );

        Db::getInstance()->Execute(
            'INSERT INTO `' . _DB_PREFIX_ . 'transporter_store_order` (`id_cart`, `id_order`, `id_carrier`, `store`) 
            VALUES (' . (int) $order->id_cart . ', ' . $idOrder . ', ' . (int) $idCarrier . ", 
            '" . pSQL(Tools::jsonEncode($store)) . "')"
        );

        $transporter = Module::getInstanceByName('transporter');

        $address = new Address($order->id_address_delivery);

        $storeAddress = new Address();

        foreach ($address as $name => $value) {
            if (!is_array($value) && !in_array($name, array('date_upd', 'date_add', 'id', 'country'))) {
                switch ($name) {
                    case 'id_customer':
                        $storeAddress->id_customer = $order->id_customer;
                        break;
                    case 'firstname':
                        $storeAddress->firstname = 'Entrega en ';
                        break;
                    case 'lastname':
                        $storeAddress->lastname = 'Transporter Store';
                        break;
                    case 'address1':
                        $storeAddress->address1 = $store['direccion'];
                        break;
                    case 'address2':
                        $storeAddress->address2 = $store['nombre'];
                        break;
                    case 'postcode':
                        $storeAddress->postcode = $store['codigoPostal']['codigoPostal'];
                        break;
                    case 'city':
                        $storeAddress->city = $store['codigoPostal']['ciudad'];
                        break;
                    case 'alias':
                        $storeAddress->alias = 'Transporter Store';
                        break;
                    case 'deleted':
                        $storeAddress->deleted = true;
                        break;
                    default:
                        $storeAddress->$name = $value;
                }
            }
        }

        $storeAddress->save();
        if ($storeAddress->id) {
            $order->id_address_delivery = $storeAddress->id;
            $order->update();
        }

        $envioJson = TransporterCommon::getEnvioJsonFromOrder($order);
        $response = $transporter->api->postEnvio($envioJson);

        TransporterFront::postOrder($order, $response);
    }
}
