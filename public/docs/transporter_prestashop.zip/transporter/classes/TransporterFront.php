<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

class TransporterFront
{
    public static function postStoreOrder($params)
    {
        $cart = Context::getContext()->cart;
        if ($cart->id_carrier) {
            $idCarrier = $cart->id_carrier;
        } elseif (isset($params['idCarrier'])) {
            $idCarrier = $params['idCarrier'];
        }

        Db::getInstance()->delete(
            'transporter_store_order',
            'id_cart = ' . $cart->id
        );

        Db::getInstance()->Execute(
            'INSERT INTO `' . _DB_PREFIX_ . 'transporter_store_order` (`id_cart`, `id_order`, `id_carrier`, `store`) 
            VALUES (' . (int) $cart->id . ', 0, ' . (int) $idCarrier . ", 
            '" . pSQL(Tools::jsonEncode($params['store'])) . "')"
        );
    }

    public static function postOrder($order, $response)
    {
        if(is_array($response) && array_key_exists('errors', $response)) {
            Db::getInstance()->Execute(
                'INSERT INTO `' . _DB_PREFIX_ . 'transporter_orders` (`id_order`, `id_shipment`, `error`) 
            VALUES (' . (int) $order->id . ', 0, "' . pSQL(Tools::jsonEncode($response['errors'])) . '")'
            );
        } else {
            Db::getInstance()->Execute(
                'INSERT INTO `' . _DB_PREFIX_ . 'transporter_orders` (`id_order`, `id_shipment`) 
            VALUES (' . (int) $order->id . ', ' . (int) $response . ')'
            );
        }

    }
}
