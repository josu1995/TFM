<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once _PS_MODULE_DIR_ . 'transporter/classes/TransporterApi.php';
require_once _PS_MODULE_DIR_ . 'transporter/classes/TransporterAdmin.php';
require_once _PS_MODULE_DIR_ . 'transporter/classes/TransporterCommon.php';
require_once _PS_MODULE_DIR_ . 'transporter/classes/TransporterFront.php';

class Transporter extends Module
{
    private $module_link;

    public $dev = true;

    public $tr_url;

    public $apiUrl;

    public $api;

    public function __construct()
    {
        $this->name = 'transporter';
        $this->tab = 'shipping_logistics';
        $this->version = '1.0.0';
        $this->author = 'Transporter';
//        $this->need_instance = 0;
        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Transporter Business');
        $this->description = $this->l('Solución integral basada en la nube que simplifica la gestión logística de tu tienda online.');

        $this->confirmUninstall = $this->l('¿Estás seguro de que quieres desinstalar el módulo Transporter?');

        if ($this->dev) {
            $this->tr_url = 'https://ingen.transporters.com.es';
            $this->apiUrl = 'https://ingen.transporters.com.es/api/tbusiness';
        } else {
            $this->tr_url = 'https://transporter.es';
            $this->apiUrl = 'https://transporter.es/api/tbusiness';
        }

        if (Configuration::get('TR_API_KEY')) {
            $this->api = new TransporterApi($this->apiUrl, Configuration::get('TR_API_KEY'));
        }
    }

    /**
     * Module install
     *
     * @return bool if install was successfull
     */
    public function install()
    {
        // Install default
        if (!parent::install()) {
            return false;
        }

        // Install SQL
        $sql = array();
        include dirname(__FILE__) . '/sql/install.php';
        foreach ($sql as $s) {
            if (!Db::getInstance()->Execute($s)) {
                return false;
            }
        }

        if (!Configuration::updateValue('TR_API_KEY', '')) {
            return false;
        }

        if (!Configuration::updateValue('TR_API_URL', 'https://ingen.transporters.com.es/api/tbusiness')) {
            return false;
        }

        if (!Configuration::updateValue('TR_MAPS_API_KEY', '')) {
            return false;
        }

        if (!Configuration::updateValue('TR_CREAR_ENVIOS', '')) {
            return false;
        }

        if (!Configuration::updateValue('TR_ESTADOS', '')) {
            return false;
        }

        if (!$this->createAdminTab()) {
            return false;
        }

        if (!$this->registerHook('header') ||
            !$this->registerHook('newOrder') ||
            !$this->registerHook('displayAdminOrder') ||
            !$this->registerHook('actionAdminOrdersRequest') ||
            !$this->registerHook('actionAdminOrderRequest') ||
            !$this->registerHook('displayBackOfficeHeader')
        ) {
            return false;
        }

        if (version_compare(_PS_VERSION_, '1.7', '>')) {
            if (!$this->registerHook('displayCarrierExtraContent')) {
                return false;
            }
        } else {
            if(!$this->registerHook('extraCarrier')) {
                return false;
            }
        }

        return true;
    }

    public function uninstall()
    {
        // Uninstall default
        if (!parent::uninstall()) {
            return false;
        }

        if (!Configuration::deleteByName('TR_API_KEY')) {
            return false;
        }

        if (!Configuration::deleteByName('TR_API_URL')) {
            return false;
        }

        if (!Configuration::deleteByName('TR_MAPS_API_KEY')) {
            return false;
        }

        if (!Configuration::deleteByName('TR_CREAR_ENVIOS')) {
            return false;
        }

        if (!Configuration::deleteByName('TR_ESTADOS')) {
            return false;
        }

        for($i = 0 ; $i < 14 ; $i++) {
            Configuration::deleteByName('TR_ESTADOS_' . $i);
        }

        if (!$this->deleteAdminTabs('AdminTabTransporter')) {
            return false;
        }

        if (!$this->unregisterHook('header') ||
            !$this->unregisterHook('newOrder') ||
            !$this->unregisterHook('displayAdminOrder') ||
            !$this->unregisterHook('actionAdminOrdersRequest') ||
            !$this->unregisterHook('actionAdminOrderRequest') ||
            !$this->unregisterHook('displayBackOfficeHeader')
        ) {
            return false;
        }

        if (version_compare(_PS_VERSION_, '1.7', '>')) {
            if (!$this->unregisterHook('displayCarrierExtraContent')) {
                return false;
            }
        } else {
            if(!$this->unregisterHook('extraCarrier')) {
                return false;
            }
        }

        Db::getInstance()->update(
            'carrier',
            array('deleted' => 1),
            'external_module_name = \'transporter\''
        );

        // Uninstall SQL
        $sql = array();
        include dirname(__FILE__) . '/sql/uninstall.php';
        foreach ($sql as $s) {
            if (!Db::getInstance()->Execute($s)) {
                return false;
            }
        }

        return true;
    }

    public function createAdminTab()
    {
        $data = array(
            'id_parent' => Tab::getIdFromClassName('AdminParentShipping'),
            'className' => 'AdminTabTransporter',
            'default_name' => 'Transporter',
            'name' => 'Transporter',
            'active' => true,
            'module' => $this->name,
        );

        if (is_array(current($data))) {
            $ids = array();

            foreach ($data as $tab) {
                $ids[] = PlTotAdminTabHelper::addAdminTab($tab);
            }

            return $ids;
        }

        // Get ID Parent
        if (isset($data['id_parent'])) {
            $id_parent = $data['id_parent'];
        } else {
            $id_parent = (int) Tab::getIdFromClassName($data['classNameParent']);
        }

        // Tab
        $tab = Tab::getInstanceFromClassName($data['className']);

        $tab->id_parent = (int) $id_parent;
        $tab->class_name = $data['className'];
        $tab->module = $data['module'];
        $tab->position = Tab::getNewLastPosition((int) $id_parent);
        $tab->active = $data['active'];

        $languages = Language::getLanguages(false);

        foreach ($languages as $lang) {
            $tab->name[(int) $lang['id_lang']] = $data['name'];
        }

        if (!$tab->save()) {
            return false;
        }

        return true;
    }

    public function deleteAdminTabs($name)
    {
        // Get collection from module if tab exists
        $tabs = Tab::getCollectionFromModule($name);
        // Initialize result
        $result = true;
        // Check tabs
        if ($tabs && count($tabs)) {
            // Loop tabs for delete
            foreach ($tabs as $tab) {
                $result &= $tab->delete();
            }
        }

        return $result;
    }

    /**
     * Admin display
     *
     * @return string Display admin content
     */
    public function getContent()
    {
        $suffixLink = '&configure=' . $this->name . '&token=' . Tools::getValue('token');
        $suffixLink .= '&tab_module=' . $this->tab . '&module_name=' . $this->name;
        $output = '';

        $default_language = new Country(Configuration::get('PS_COUNTRY_DEFAULT'));
        $language = Tools::strtolower($default_language->iso_code);

        if ($language != 'it' && $language != 'es' && $language != 'fr' && $language != 'de') {
            $language = 'es';
        }

        // Inicializamos parametros
        $tab_name = 'home_settings';
        $unit_weight = Configuration::get('PS_WEIGHT_UNIT');
        $unit_length = Configuration::get('PS_DIMENSION_UNIT');

        $generate_api = $this->tr_url . '/business/configuracion/api';
        $register_link = $this->tr_url . '/business/registro';
        $direccionRecogidaLink = $this->tr_url . '/business/configuracion/punto-recogida';
        $linkEstados = $this->context->link->getAdminLink('AdminStatuses');

        $this->module_link = 'index.php?controller=' . Tools::getValue('controller') . $suffixLink;

        $default_lang = $this->context->language->id;
        $order_state = OrderState::getOrderStates($default_lang);

        // Miramos si se han emitido queries
        if (Tools::getValue('submit-query')) {
            $TR_API_KEY = Tools::getValue('TR_API_KEY');
            Configuration::updateValue('TR_API_KEY', $TR_API_KEY);

            $TR_MAPS_API_KEY = Tools::getValue('TR_MAPS_API_KEY');
            Configuration::updateValue('TR_MAPS_API_KEY', $TR_MAPS_API_KEY);

            $output .= $this->displayConfirmation($this->l('Clave de API modificada correctamente.'));
        } else {
            $TR_API_KEY = Configuration::get('TR_API_KEY');
            $TR_MAPS_API_KEY = Configuration::get('TR_MAPS_API_KEY');
        }

        // Inicializamos API
        $this->api = new TransporterApi($this->apiUrl, $TR_API_KEY);

        // Validamos la primera vez
        if (Tools::getValue('submit-query')) {
            $response = $this->api->validate();
            Db::getInstance()->update('transporter_carrier', [
                'active' => true
            ], 'account_type = ' . $response->tiposRecogida);
            Db::getInstance()->update('transporter_carrier', [
                'active' => false
            ], 'account_type != ' . $response->tiposRecogida);
        }

        $recogida = $this->api->getDireccionRecogida();
        $estadosTransporter = $this->api->getEstados();
        $transportistas = $this->api->getTransportistas();

        if (Tools::getValue('submit-status')) {
            $estadosPrestashop = [];
            Db::getInstance()->delete('transporter_states');
            foreach ($estadosTransporter as $estado) {
                Db::getInstance()->insert('transporter_states', [
                    'id' => $estado->id,
                    'name' => $estado->nombre,
                    'description' => $estado->descripcion
                ]);
            }
            foreach (Tools::getValue('estados') as $key => $estado) {
                $estadosPrestashop[$estadosTransporter[$key]->id] = $estado;
                Configuration::updateValue('TR_ESTADOS_' . $estadosTransporter[$key]->id, $estado);
                Db::getInstance()->update('transporter_states', [
                    'ps_state_id' => $estado
                ], 'id = ' . $estadosTransporter[$key]->id);
            }

            $output .= $this->displayConfirmation($this->l('Estados modificados correctamente.'));
        } elseif ($estadosTransporter) {
            $estadosPrestashop = [];
            foreach ($estadosTransporter as $estado) {
                $estadosPrestashop[$estado->id] = Configuration::get('TR_ESTADOS_' . $estado->id);
            }
        } else {
            $estadosPrestashop = null;
        }

        if (Tools::getValue('submit-carrier')) {
            foreach ($transportistas as $data) {
                foreach ($data as $zona) {
                    foreach ($zona->transportistas_prestashop as $transportista) {
                        if ($transportista->id == Tools::getValue('carrier-id')) {
                            $result = TransporterAdmin::addTransportista($transportista);
                            if ($result) {
                                Tools::redirectAdmin($this->context->link->getAdminLink('AdminCarrierWizard', true) . '&id_carrier=' . $result->id);
                            }
                        }
                    }
                }
            }
        }

        $transportistasCreados = TransporterAdmin::getTransportistasCreados();

        $this->context->smarty->assign(array(
            'TR_API_KEY' => $TR_API_KEY,
            'TR_MAPS_API_KEY' => $TR_MAPS_API_KEY,
            'register_link' => $register_link,
            'generate_api' => $generate_api,
            'module_link' => $this->module_link,
            'language' => $language,
            'link' => $this->context->link,
            'weight' => 1,
            'length' => 1,
            'unit_weight' => $unit_weight,
            'unit_length' => $unit_length,
            'packlink_import' => 1,
            'simple_link' => $this->_path,
            'update_msg' => '',
            'order_state' => $order_state,
            'status_awaiting' => 0,
            'status_pending' => 0,
            'status_ready' => 0,
            'status_transit' => 0,
            'status_delivered' => 0,
            'tab_name' => $tab_name,
            'link_units' => '',
            'linkEstados' => $linkEstados,
            'direccionRecogidaLink' => $direccionRecogidaLink,
            'warehouses' => [],
            'show_address' => '',
            'pl_aide' => '',
            'recogida' => $recogida,
            'estadosTransporter' => $estadosTransporter,
            'estadosPrestashop' => $estadosPrestashop,
            'transportistas' => $transportistas,
            'transportistasCreados' => $transportistasCreados,
        ));

        $this->context->controller->addCSS($this->_path . 'views/css/style.css', 'all');

        return $output . $this->display(__FILE__, 'views/templates/hook/back.tpl');
    }

    // Hooks
    public function hookHeader($params)
    {
        if (!($file = basename(Tools::getValue('controller')))) {
            $file = str_replace('.php', '', basename($_SERVER['SCRIPT_NAME']));
        }

        $transportistasCreados = TransporterAdmin::getTransportistasCreados();

        if (in_array($file, array('order-opc', 'order', 'orderopc', 'history', 'supercheckout', 'amzpayments')) && $transportistasCreados) {
            $cart = $params['cart'];
            $address = new Address($cart->id_address_delivery);
            $country = new Country($address->id_country);
            $postcode = $address->postcode;

            $this->context->controller->addJS($this->_path . 'views/js/front/transporter.js');

            $this->context->controller->addCSS($this->_path . 'views/css/front/style.css');
            if (version_compare(_PS_VERSION_, '1.7', '<')) {
                $this->context->controller->addCSS($this->_path . 'views/css/front/bootstrap.min.css');
            }

            $transportistas = array_map(function ($carrier) {
                return intval($carrier['id_carrier']);
            }, $transportistasCreados);

            $trStoreOrder = TransporterCommon::getTransporterStoreOrder('id_cart = ' . $cart->id);

            if($trStoreOrder) {
                $selStore = json_decode($trStoreOrder['store'])->id;
            } else {
                $selStore = 0;
            }


            $transporterCfg = array(
                'mapsKey' => Configuration::get('TR_MAPS_API_KEY'),
                'carriers' => $transportistas,
                'ajaxUrl' => $this->context->link->getModuleLink('transporter', 'ajax', array(), Tools::usingSecureMode()),
                'postcode' => $postcode,
                'country' => $country->iso_code,
                'selectedStore' => $selStore
            );

            $response = $this->api->getStores($address->address1 . ' ' . $address->address2, $postcode, $address->city, $country->iso_code);

            if($response) {
                Media::addJsDef(array('trDireccion' => $response->direccion));
                Media::addJsDef(array('trStores' => $response->stores));
                Media::addJsDef(array('TransporterCfg' => $transporterCfg));
            }

            return;
        }
    }

    public function hookdisplayBackOfficeHeader()
    {
        if (Tools::getValue('controller') == 'AdminOrders' && Tools::getValue('id_order')) {
            $order = new Order(Tools::getValue('id_order'));
            if(Tools::getValue('shipping_carrier')) {
                $idCarrier = Tools::getValue('shipping_carrier');
            } else {
                $idCarrier = $order->id_carrier;
            }
            $orderCarrierReference = (new Carrier($idCarrier))->id_reference;
            $trOrder = TransporterCommon::getTransporterOrder('id_order = ' . $order->id);
            $trCarrier = TransporterCommon::getTransportistas(true, 'id_reference = ' . $orderCarrierReference);
            if(!$trOrder && $trCarrier && $trCarrier['store_delivery']) {
                $this->context->controller->addJS($this->_path . 'views/js/admin/transporter.js');
                $this->context->controller->addCSS($this->_path . 'views/css/front/style.css');

                $cart = new Cart($order->id_cart);
                $address = new Address($cart->id_address_delivery);
                $country = new Country($address->id_country);
                $postcode = $address->postcode;
                $transportistasCreados = TransporterAdmin::getTransportistasCreados();

                $transportistas = array_map(function ($carrier) {
                    return intval($carrier['id_carrier']);
                }, $transportistasCreados);

                $transporterCfg = array(
                    'mapsKey' => Configuration::get('TR_MAPS_API_KEY'),
                    'carriers' => $transportistas,
                    'ajaxUrl' => $this->context->link->getAdminLink('AdminTransporter'),
                    'postcode' => $postcode,
                    'country' => $country->iso_code,
                    'selectedStore' => 0,
                    'idCarrier' => $order->id_carrier,
                    'idOrder' => $order->id,
                );

                Media::addJsDef(array('TransporterCfg' => $transporterCfg));
            }
        }
    }

    public function hookdisplayCarrierExtraContent($params)
    {
        $carrier = $params['carrier'];
        $cart = $params['cart'];
        if ($carrier['external_module_name'] != $this->name) {
            return false;
        }
        $address = new Address($cart->id_address_delivery);
        $country = new Country($address->id_country);
        $postcode = $address->postcode;

        if (!$cart->id_address_delivery) {
            return false;
        }
        $transporterCarrier = TransporterCommon::getTransportistas(true, '`id_reference` = ' . (int) $carrier['id_reference']);

        if ($transporterCarrier && $transporterCarrier['store_delivery']) {
            $response = $this->api->getStores($address->address1 . ' ' . $address->address2, $postcode, $address->city, $country->iso_code);

            $params = array(
                'carrierId' => $carrier['id'],
                'direccion' => $response->direccion,
                'stores' => $response->stores,
                'rootLink' => $this->_path,
                'address' => $address->address1,
            );

            $this->smarty->assign(array('params' => $params));

            return $this->display(__FILE__, 'views/templates/hook/displayCarrierExtraContent.tpl');
        }

        return false;
    }

    public function hookExtraCarrier($params)
    {
        $cart = $params['cart'];
        $address = new Address($cart->id_address_delivery);
        $carriers = $cart->getDeliveryOptionList()[$cart->id_address_delivery];

        $params = array();

        foreach ($carriers as $addressCarriers) {
            foreach ($addressCarriers['carrier_list'] as $key => $carrier) {
                $carrier = new Carrier($key);
                $transporterCarrier = TransporterCommon::getTransportistas(true, '`id_reference` = ' . (int) $carrier->id_reference);
                if ($transporterCarrier && $transporterCarrier['store_delivery']) {
                    $country = new Country($address->id_country);
                    $postcode = $address->postcode;
                    $response = $this->api->getStores($address->address1 . ' ' . $address->address2, $postcode, $address->city, $country->iso_code);
                    array_push($params, array(
                        'carrierId' => $carrier->id,
                        'direccion' => $response->direccion,
                        'stores' => $response->stores,
                        'rootLink' => $this->_path,
                        'address' => $address->address1,
                    ));
                }
            }
        }

        $this->smarty->assign(array('params' => $params));

        return $this->display(__FILE__, 'views/templates/hook/displayExtraCarrier.tpl');

    }

    public function hookNewOrder($params)
    {
        $carrier = new Carrier((int) $params['order']->id_carrier);
        $result = TransporterCommon::getTransportistas(true, '`id_reference` = ' . (int) $carrier->id_reference);
        if (!$result) {
            return false;
        }
        $order = $params['order'];

        if($result['store_delivery'] == 1) {

            $row = Db::getInstance()->getRow(
                'SELECT `store` FROM `' . _DB_PREFIX_ . 'transporter_store_order` 
            WHERE `id_cart` = ' . (int)$params['cart']->id . ' AND `id_carrier` = ' . (int)$params['order']->id_carrier
            );

            $store = Tools::jsonDecode($row['store']);

            // Current address
            $address = new Address($params['order']->id_address_delivery);

            // Store address
            $storeAddress = new Address();

            foreach ($address as $name => $value) {
                if (!is_array($value) && !in_array($name, array('date_upd', 'date_add', 'id', 'country'))) {
                    switch ($name) {
                        case 'id_customer':
                            $storeAddress->id_customer = $params['order']->id_customer;
                            break;
                        case 'firstname':
                            $storeAddress->firstname = 'Entrega en ';
                            break;
                        case 'lastname':
                            $storeAddress->lastname = 'Transporter Store';
                            break;
                        case 'address1':
                            $storeAddress->address1 = $store->direccion;
                            break;
                        case 'address2':
                            $storeAddress->address2 = $store->nombre;
                            break;
                        case 'postcode':
                            $storeAddress->postcode = $store->codigoPostal->codigoPostal;
                            break;
                        case 'city':
                            $storeAddress->city = $store->codigoPostal->ciudad;
                            break;
                        case 'alias':
                            $storeAddress->alias = 'Transporter Store';
                            break;
                        case 'deleted':
                            $storeAddress->deleted = true;
                            break;
                        default:
                            $storeAddress->$name = $value;
                    }
                }
            }

            $storeAddress->save();
            if ($storeAddress->id) {
                $order->id_address_delivery = $storeAddress->id;
                $order->update();
            }

            Db::getInstance()->update(
                'transporter_store_order',
                array('id_order' => (int)$params['order']->id),
                '`id_cart` = ' . (int)$params['cart']->id . ' AND `id_carrier` = ' . (int)$params['order']->id_carrier
            );
        }

        $envioJson = TransporterCommon::getEnvioJsonFromOrder($order);
        $response = $this->api->postEnvio($envioJson);

        TransporterFront::postOrder($order, $response);
    }

    public function hookdisplayAdminOrder()
    {
        $orderId = Tools::getValue('id_order');
        $order = new Order($orderId);

        if(Tools::getValue('retry_tr_shipment')) {
            $envioJson = TransporterCommon::getEnvioJsonFromOrder($order);
            $response = $this->api->postEnvio($envioJson);
            TransporterAdmin::updateOrder($order, $response);
            Tools::redirectAdmin(Context::getContext()->link->getAdminLink('AdminOrders')."&id_order=".$orderId."&vieworder");
        }

        if(Tools::getValue('create_tr_shipment')) {
            $envioJson = TransporterCommon::getEnvioJsonFromOrder($order);
            $response = $this->api->postEnvio($envioJson);
            TransporterFront::postOrder($order, $response);
            Tools::redirectAdmin(Context::getContext()->link->getAdminLink('AdminOrders')."&id_order=".$orderId."&vieworder");
        }

        $orderCarrierReference = (new Carrier($order->id_carrier))->id_reference;
        $trOrder = TransporterCommon::getTransporterOrder('id_order = ' . $orderId);
        $trCarrier = TransporterCommon::getTransportistas(true, 'id_reference = ' . $orderCarrierReference);

        if($trOrder) {
            if ($trOrder['error']) {
                $params = array(
                    'errors' => json_decode($trOrder['error']),
                    'text' => $this->l('Reintentar'),
                    'icon' => 'icon-mail-reply',
                    'class' => '',
                    'retryLink' => Context::getContext()->link->getAdminLink('AdminOrders') . "&id_order=" . $orderId . "&vieworder&retry_tr_shipment=1",
                );
            } else {
                $state = TransporterCommon::getTransporterState('ps_state_id = ' . $order->current_state);
                if (!$state) {
                    $state = ['description' => $this->l('No has configurado tus estados desde la página de configuración.')];
                }
                $params = array(
                    'state' => $state['description'],
                    'text' => $this->l('Ver'),
                    'icon' => 'icon-eye',
                    'class' => '',
                    'trLink' => $this->tr_url . '/business/envios/pendientes-pago',
                );
            }
        } elseif ($trCarrier) {
            if(intval($trCarrier['store_delivery'])) {
                $params = array(
                    'state' => $this->l('El envío no ha sido creado aún.'),
                    'text' => $this->l('Crear'),
                    'icon' => 'icon-plus',
                    'class' => 'tr-crear-envio',
                    'trLink' => ''
                );
            } else {
                $params = array(
                    'state' => $this->l('El envío no ha sido creado aún.'),
                    'text' => $this->l('Crear'),
                    'icon' => 'icon-plus',
                    'class' => 'tr-crear-envio',
                    'trLink' => Context::getContext()->link->getAdminLink('AdminOrders') . "&id_order=" . $orderId . "&vieworder&create_tr_shipment=1"
                );
            }
        } else {
            $params = array(
                'message' => $this->l('Transporter no ha sido seleccionado como transportista'),
            );
        }

        if (!$trOrder && $trCarrier && $trCarrier['store_delivery']) {
            $cart = new Cart($order->id_cart);
            $address = new Address($cart->id_address_delivery);
            $country = new Country($address->id_country);
            $postcode = $address->postcode;

            $response = $this->api->getStores($address->address1 . ' ' . $address->address2, $postcode, $address->city, $country->iso_code);

            $params['params'] = array(
                'carrierId' => $order->id_carrier,
                'direccion' => $response->direccion,
                'stores' => $response->stores,
                'rootLink' => $this->_path,
                'address' => $address->address1,
            );

            Media::addJsDef(array('trDireccion' => $response->direccion));
            Media::addJsDef(array('trStores' => $response->stores));
        }

        $this->smarty->assign($params);
        return  $this->display(__FILE__, 'views/templates/hook/adminOrder.tpl');
    }

    public function hookactionAdminOrderRequest()
    {
        if($this->api) {
            $order = new Order(Tools::getValue('id_order'));
            $trOrder = TransporterCommon::getTransporterOrder('id_order = ' . Tools::getValue('id_order'));
            if($trOrder && $trOrder['id_shipment'] != 0) {
                $estado = $this->api->getEstadoEnvio($trOrder['id_shipment']);
                if($estado) {
                    if($estado->deleted) {
                        TransporterCommon::deleteTransporterOrder($estado->id);
                    } else {
                        $psEstado = Configuration::get('TR_ESTADOS_' . $estado->id);
                        if ($psEstado) {
                            $this->updateOrderStateAndShippingNumber($order, $psEstado, $estado->localizador, $estado->fecha);
                        }
                    }
                }
            }
        }
    }

    public function hookactionAdminOrdersRequest()
    {
        if($this->api) {
            $psEnvios = TransporterCommon::getEnviosNoFinalizados();
            if($psEnvios) {
                $estados = $this->api->getEstadosEnvios($psEnvios);
                foreach ($estados as $estado) {
                    if($estado->deleted) {
                        TransporterCommon::deleteTransporterOrder($estado->id);
                    } else {
                        $psEstado = Configuration::get('TR_ESTADOS_' . $estado->estado);
                        if ($psEstado) {
                            $trOrder = TransporterCommon::getTransporterOrder('id_shipment = ' . $estado->id);
                            if ($trOrder) {
                                $psOrder = new Order($trOrder['id_order']);
                                $this->updateOrderStateAndShippingNumber($psOrder, $psEstado, $estado->localizador, $estado->fecha);
                            }
                        }
                    }
                }
            }
        }
    }

    private function updateOrderStateAndShippingNumber($psOrder, $psEstado, $localizador, $date)
    {
        // Seteamos estado
        if ($psOrder->current_state != $psEstado) {
            $psOrder->setCurrentState($psEstado);
            Db::getInstance()->update('order_history', [
                'date_add' => $date
            ], 'id_order = ' . $psOrder->id . ' and id_order_state = ' . $psEstado);
        }
        // Seteamos localizador
        if (method_exists($psOrder, 'getWsShippingNumber') && !$psOrder->getWsShippingNumber() && method_exists($psOrder, 'setWsShippingNumber')) {
            $psOrder->setWsShippingNumber($localizador);
        } else {
            $idOrderCarrier = Db::getInstance()->getValue('
                                SELECT `id_order_carrier`
                                FROM `' . _DB_PREFIX_ . 'order_carrier`
                                WHERE `id_order` = ' . (int)$psOrder->id);
            if ($idOrderCarrier) {
                $orderCarrier = new OrderCarrier($idOrderCarrier);
                if (!$orderCarrier->tracking_number) {
                    $orderCarrier->tracking_number = $localizador;
                    $orderCarrier->update();
                }
            }
        }
    }

    // Overrides
    public function getOrderShippingCost($cart, $shipping_cost)
    {
        return $shipping_cost;
    }

    public function getOrderShippingCostExternal($params)
    {
        return true;
    }
}
