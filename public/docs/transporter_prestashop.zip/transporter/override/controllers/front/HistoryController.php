<?php

class HistoryController extends HistoryControllerCore
{
    public function initContent()
    {
        Hook::exec('actionAdminOrdersRequest');
        return parent::initContent();
    }
}
