<?php

class OrderDetailController extends OrderDetailControllerCore
{
    public function postProcess()
    {
        Hook::exec('actionAdminOrderRequest');
        return parent::postProcess();
    }
}
