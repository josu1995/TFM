<?php

class AdminOrdersController extends AdminOrdersControllerCore
{
    public function renderList()
    {
        Hook::exec('actionAdminOrdersRequest');
        return parent::renderList();
    }

    public function postProcess()
    {
        if(Tools::isSubmit('id_order') && Tools::getValue('id_order') > 0) {
            Hook::exec('actionAdminOrderRequest');
        }
        return parent::postProcess();
    }
}